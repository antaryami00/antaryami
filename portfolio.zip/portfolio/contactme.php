<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if(isset($_POST['sendContact'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'roulantaryami3@gmail.com';
        $mail->Password   = 'gtywbemlsgvdefyq';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        //Recipients
        $mail->setFrom('roulantaryami3@gmail.com', 'Portfolio Netlify');
        $mail->addAddress('roulantaryami3@gmail.com', 'Portfolio Visitor');
        //Content
        $mail->isHTML(true);
        $mail->Subject = 'Netlify Portfolio Contact';
        $mail->Body    = '  <h3>Hello, You got a New Enquiry</h3>
                    <h5>FullName : '.$name.'</h5>
                    <h5>Email : '.$email.'</h5>
                    <h5>Subject : '.$subject.'</h5>
                    <h5>Message : '.$message.'</h5>';

        if($mail->send()){
            echo ' <script>
                    Swal.fire({
                    title: "Thank You !",
                    text: "Thank You For Contacting. You will receive a reply soon.",
                    icon: "success"
                    });
                </script>';
            header("Location:index.html");
            exit(0);
        }
        else{
            echo '<script> alert("Error sending mail, Please try again after some time.")</script>';
            header("Location:index.html");
            exit(0);
        }
        
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
else{
    header('Location:index.html');
    exit(0);
}
?>